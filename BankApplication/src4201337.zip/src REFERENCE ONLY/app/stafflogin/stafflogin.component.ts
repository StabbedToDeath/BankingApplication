import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stafflogin',
  templateUrl: './stafflogin.component.html',
  styleUrls: ['./stafflogin.component.css']
})
export class StaffloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
