import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerAccountComponent } from './customer-account/customer-account.component';
import { CustomerEnableBlockComponent } from './customer-enable-block/customer-enable-block.component';
import { CustomerCreditDebitComponent } from './customer-credit-debit/customer-credit-debit.component';
import { BeneficiaryApproveModifyComponent } from './beneficiary-approve-modify/beneficiary-approve-modify.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { StaffloginComponent } from './stafflogin/stafflogin.component';
import { StafflogoutComponent } from './stafflogout/stafflogout.component';
import { StaffheaderComponent } from './staffheader/staffheader.component';
import { StaffhomeComponent } from './staffhome/staffhome.component';
import {MatTabsModule} from '@angular/material/tabs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatHeaderRow, MatRow, MatTableModule} from '@angular/material/table';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { HttpClientModule } from '@angular/common/http';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { ApproveDisableComponent } from './approve-disable/approve-disable.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';



@NgModule({
  declarations: [
    AppComponent,
    CustomerAccountComponent,
    CustomerEnableBlockComponent,
    CustomerCreditDebitComponent,
    BeneficiaryApproveModifyComponent,
    AccountStatementComponent,
    StaffloginComponent,
    StafflogoutComponent,
    StaffheaderComponent,
    StaffhomeComponent,
    ApproveDisableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatTabsModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatToolbarModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    HttpClientModule,
    MatCardModule,
    MatIconModule,
    FormsModule,
    MatTableModule,
    MatSlideToggleModule,
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
