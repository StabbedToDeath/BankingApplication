import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StaffService {

  baseurl:string = "http://localhost:8080/api/staff/";

  constructor(private http:HttpClient) { }

  getAllCustomer()
  {
    return this.http.get(`${this.baseurl}customer`);
  }

  changeStatus(customer:any)  //FIELDS
  {
    return this.http.put(`${this.baseurl}customer`, customer  );
  }

  getCustomer(id:any)
  {
    return this.http.get(`${this.baseurl}customer/` + id);
  }

  getStatement(accNo:any)
  {
    return this.http.get(`${this.baseurl}account/` + accNo);
  }
  
  getNotApprovedBens()
  {
    return this.http.get(`${this.baseurl}beneficiary`);
  }

  approveBeneficiary(beneficiary:any)  //FIELDS
  {
    return this.http.put(`${this.baseurl}beneficiary`, beneficiary);
  }

  getNotApprovedAccounts()
  {
    return this.http.get(`${this.baseurl}accounts/approve`);
  }

  approveAccount(account:any)  //Fields
  {
    
    return this.http.put(`${this.baseurl}accounts/approve`, account);
  }

  transfer(transaction:any)  //FIELDS
  {
    return this.http.put(`${this.baseurl}transfer`, transaction);
  }

  authenticate()  //FIELDS
  {
    return this.http.get(`${this.baseurl}authenticate`);
  }

}
