import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staffheader',
  templateUrl: './staffheader.component.html',
  styleUrls: ['./staffheader.component.css']
})
export class StaffheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  stafflogin()
  {

  }
  
  stafflogout()
  {

  }
}
