import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-credit-debit',
  templateUrl: './customer-credit-debit.component.html',
  styleUrls: ['./customer-credit-debit.component.css']
})
export class CustomerCreditDebitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
