import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StafflogoutComponent } from './stafflogout.component';

describe('StafflogoutComponent', () => {
  let component: StafflogoutComponent;
  let fixture: ComponentFixture<StafflogoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StafflogoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StafflogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
