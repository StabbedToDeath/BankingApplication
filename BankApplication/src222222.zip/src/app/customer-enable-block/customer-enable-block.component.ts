import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-enable-block',
  templateUrl: './customer-enable-block.component.html',
  styleUrls: ['./customer-enable-block.component.css']
})
export class CustomerEnableBlockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
