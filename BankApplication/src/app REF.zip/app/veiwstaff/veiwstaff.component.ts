import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-veiwstaff',
  templateUrl: './veiwstaff.component.html',
  styleUrls: ['./veiwstaff.component.css']
})
export class VeiwstaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
