    export class Staff{
        staffId!:number;
      
       staffFullName!:string;
      
       staffUserName!:string;
      
       staffPassword!:string;
  
       status!:boolean;
      }

