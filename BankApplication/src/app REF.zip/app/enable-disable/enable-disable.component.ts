import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enable-disable',
  templateUrl: './enable-disable.component.html',
  styleUrls: ['./enable-disable.component.css']
})
export class EnableDisableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
