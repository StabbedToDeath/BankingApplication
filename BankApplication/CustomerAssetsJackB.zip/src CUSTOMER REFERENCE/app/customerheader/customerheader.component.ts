import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerheader',
  templateUrl: './customerheader.component.html',
  styleUrls: ['./customerheader.component.css']
})
export class CustomerheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
