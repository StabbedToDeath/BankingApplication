import { Component, OnInit } from '@angular/core';
import { Form } from '@angular/forms';
import { Router } from '@angular/router';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-customer-account',
  templateUrl: './customer-account.component.html',
  styleUrls: ['./customer-account.component.css']
})
export class CustomerAccountComponent implements OnInit {

  constructor(private router: Router, private staffService:StaffService,) { }

  statement:any;
  account:any;
  transactions:any = [];

  ngOnInit(): void {
    
  }


  getStatement(form:any)
  {
    
    this.staffService.getStatement(1).subscribe(res => 
    {
      console.log(res);
       this.account = res;
       this.transactions = this.account.transactions;
       this.ngOnInit();
    
    });
  }

  // getAccountById(accNoForm:any)
  // {

  // }
}
