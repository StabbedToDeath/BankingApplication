import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { ApproveDisableComponent } from './approve-disable/approve-disable.component';
import { BeneficiaryApproveModifyComponent } from './beneficiary-approve-modify/beneficiary-approve-modify.component';
import { CustomerAccountComponent } from './customer-account/customer-account.component';
import { CustomerCreditDebitComponent } from './customer-credit-debit/customer-credit-debit.component';
import { CustomerEnableBlockComponent } from './customer-enable-block/customer-enable-block.component';
import { StaffheaderComponent } from './staffheader/staffheader.component';
import { StaffhomeComponent } from './staffhome/staffhome.component';
import { StaffloginComponent } from './stafflogin/stafflogin.component';
import { StafflogoutComponent } from './stafflogout/stafflogout.component';

const routes: Routes = [
  {
    path:"account-statement",
    component: AccountStatementComponent
  },
  {
    path: "beneficiary",
    component: BeneficiaryApproveModifyComponent
  },
  {
    path: "customer-account" ,
    component: CustomerAccountComponent
  },
  {
    path: "customer-credit-debit",
    component: CustomerCreditDebitComponent
  },
  {
    path: "customer-enable-block",
    component: CustomerEnableBlockComponent
  },
  {
    path: "staffheader",
    component: StaffheaderComponent
  },
  {
    path: "staffhome",
    component: StaffhomeComponent
  },
  {
    path: "stafflogin",
    component: StaffloginComponent
  },
  {
    path: "stafflogout",
    component: StafflogoutComponent
  },
  {
    path: "approve-disable",
    component: ApproveDisableComponent
  }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
