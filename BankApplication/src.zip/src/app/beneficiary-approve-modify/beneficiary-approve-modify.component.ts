import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beneficiary-approve-modify',
  templateUrl: './beneficiary-approve-modify.component.html',
  styleUrls: ['./beneficiary-approve-modify.component.css']
})
export class BeneficiaryApproveModifyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
