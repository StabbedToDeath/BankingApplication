import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve-disable',
  templateUrl: './approve-disable.component.html',
  styleUrls: ['./approve-disable.component.css']
})
export class ApproveDisableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
