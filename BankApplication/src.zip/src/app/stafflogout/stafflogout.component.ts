import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stafflogout',
  templateUrl: './stafflogout.component.html',
  styleUrls: ['./stafflogout.component.css']
})
export class StafflogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
